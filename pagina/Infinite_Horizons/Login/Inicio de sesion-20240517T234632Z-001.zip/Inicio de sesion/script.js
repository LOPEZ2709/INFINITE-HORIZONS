const btn= document.getElementById("btn");
const container = document.querySelector("container");


btn.addEventListener("Click",()=>{
    container.classList.toggle("toggle");
})